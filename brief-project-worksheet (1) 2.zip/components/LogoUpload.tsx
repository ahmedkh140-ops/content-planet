
import React, { useRef } from 'react';

interface LogoUploadProps {
  logoUrl?: string;
  onUpload: (url: string) => void;
}

const LogoUpload: React.FC<LogoUploadProps> = ({ logoUrl, onUpload }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onUpload(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="flex flex-col items-center">
      <div 
        onClick={() => fileInputRef.current?.click()}
        className={`w-32 h-32 md:w-36 md:h-36 border-4 border-dashed rounded-3xl flex items-center justify-center cursor-pointer transition-all overflow-hidden bg-white hover:border-brand-teal hover:bg-brand-teal/5 ${logoUrl ? 'border-brand-teal/30 border-solid' : 'border-slate-200'}`}
      >
        {logoUrl ? (
          <img src={logoUrl} alt="Logo" className="w-full h-full object-contain p-3" />
        ) : (
          <div className="text-center text-slate-300 p-4">
            <svg className="w-8 h-8 mx-auto mb-2 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <p className="text-[10px] font-bold">إضافة الشعار</p>
          </div>
        )}
      </div>
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        accept="image/*" 
        className="hidden" 
      />
      {!logoUrl && <p className="text-[10px] text-slate-400 mt-3 no-print font-medium uppercase tracking-tighter">Click to upload</p>}
    </div>
  );
};

export default LogoUpload;
