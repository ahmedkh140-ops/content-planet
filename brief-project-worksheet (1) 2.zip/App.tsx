
import React, { useState } from 'react';
import { BriefData, initialBriefData, Persona, Competitor } from './types';
import FormSection from './components/FormSection';
import { improveContent, suggestPersona, generateKeyMessages } from './services/geminiService';

const App: React.FC = () => {
  const [data, setData] = useState<BriefData>(initialBriefData);
  const [loadingField, setLoadingField] = useState<string | null>(null);

  const updateField = (field: keyof BriefData, value: any) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const updatePersona = (type: 'primary' | 'secondary', field: keyof Persona, value: string) => {
    const personaKey = type === 'primary' ? 'primaryPersona' : 'secondaryPersona';
    setData(prev => ({
      ...prev,
      [personaKey]: { ...prev[personaKey], [field]: value }
    }));
  };

  const updateCompetitor = (index: number, field: keyof Competitor, value: string) => {
    const newCompetitors = [...data.competitors];
    newCompetitors[index] = { ...newCompetitors[index], [field]: value };
    setData(prev => ({ ...prev, competitors: newCompetitors }));
  };

  const handleImprove = async (field: keyof BriefData, label: string) => {
    const currentVal = data[field] as string;
    if (!currentVal) return;
    
    setLoadingField(field as string);
    const improved = await improveContent(currentVal, label);
    updateField(field, improved);
    setLoadingField(null);
  };

  const handleSuggestPersona = async () => {
    if (!data.projectDescription) {
      alert("يرجى إدخال وصف للمشروع أولاً");
      return;
    }
    setLoadingField('persona-ai');
    const suggestion = await suggestPersona(data.projectDescription);
    if (suggestion) {
      setData(prev => ({ ...prev, primaryPersona: suggestion }));
    }
    setLoadingField(null);
  };

  const handleSuggestMessages = async () => {
    setLoadingField('messages-ai');
    const messages = await generateKeyMessages(data);
    if (messages) {
      updateField('keyMessages', messages);
    }
    setLoadingField(null);
  };

  const resetForm = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في مسح جميع البيانات؟')) {
      setData(initialBriefData);
    }
  };

  const AIButton = ({ onClick, loading, label }: { onClick: () => void, loading: boolean, label?: string }) => (
    <button
      type="button"
      onClick={onClick}
      disabled={loading}
      className="no-print mt-2 flex items-center gap-2 text-[11px] font-bold text-brand-purple hover:text-brand-purple/80 transition-colors disabled:opacity-50"
    >
      {loading ? (
        <span className="inline-block animate-spin h-3 w-3 border-2 border-brand-purple border-t-transparent rounded-full"></span>
      ) : (
        <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
        </svg>
      )}
      {label || "تحسين ذكي"}
    </button>
  );

  return (
    <div className="min-h-screen pb-32 md:p-10 p-4">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-16 flex flex-col items-center">
          <h1 className="text-3xl md:text-5xl font-extrabold text-slate-800 tracking-tight">
            Brief Project Worksheet
          </h1>
          <div className="w-20 h-1.5 bg-brand-teal rounded-full mt-6"></div>
        </div>

        <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
          
          <FormSection 
            title="1. معلومات عامة" 
            englishTitle="General Information"
            icon={<svg className="w-6 h-6 text-brand-teal" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <Input label="اسم الشركة / العلامة التجارية" value={data.companyName} onChange={v => updateField('companyName', v)} placeholder="..." />
              <Input label="الشخص المسؤول" value={data.contactPerson} onChange={v => updateField('contactPerson', v)} placeholder="..." />
              <Input label="موقع الشركة" value={data.location} onChange={v => updateField('location', v)} placeholder="..." />
              <Input label="رقم الهاتف" value={data.phone} onChange={v => updateField('phone', v)} placeholder="..." />
              <div className="md:col-span-2">
                <Input label="قنوات التواصل الاجتماعي" value={data.socialChannels} onChange={v => updateField('socialChannels', v)} placeholder="..." />
              </div>
            </div>
          </FormSection>

          <FormSection 
            title="2. وصف المشروع" 
            englishTitle="Project Description"
            borderColor="border-brand-purple"
            iconBgColor="bg-brand-purple/10"
            icon={<svg className="w-6 h-6 text-brand-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>}
          >
            <div className="space-y-6">
              <div>
                <Textarea label="وصف موجز للعمل" rows={4} value={data.projectDescription} onChange={v => updateField('projectDescription', v)} />
                <AIButton onClick={() => handleImprove('projectDescription', 'وصف المشروع')} loading={loadingField === 'projectDescription'} />
              </div>
              <div>
                <Textarea label="نقاط الألم لدى العميل" rows={3} value={data.painPoints} onChange={v => updateField('painPoints', v)} />
                <AIButton onClick={() => handleImprove('painPoints', 'نقاط الألم')} loading={loadingField === 'painPoints'} />
              </div>
            </div>
          </FormSection>

          <FormSection 
            title="3. الأهداف والغايات" 
            englishTitle="Objectives"
            icon={<svg className="w-6 h-6 text-brand-teal" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <Input label="الهدف الرئيسي" value={data.primaryGoal} onChange={v => updateField('primaryGoal', v)} />
              <Input label="الهدف الثانوي" value={data.secondaryGoal} onChange={v => updateField('secondaryGoal', v)} />
              <div className="md:col-span-2">
                <Input label="الإجراء المطلوب (CTA)" value={data.cta} onChange={v => updateField('cta', v)} />
              </div>
              <Input label="تاريخ الإطلاق المستهدف" type="date" value={data.launchDate} onChange={v => updateField('launchDate', v)} />
              <Input label="مؤشرات القياس (KPIs)" value={data.kpis} onChange={v => updateField('kpis', v)} />
            </div>
          </FormSection>

          <FormSection 
            title="4. معلومات الجمهور" 
            englishTitle="Audience"
            borderColor="border-brand-purple"
            iconBgColor="bg-brand-purple/10"
            icon={<svg className="w-6 h-6 text-brand-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>}
          >
            <div className="bg-slate-50/50 p-6 rounded-2xl mb-6 border border-slate-100">
              <div className="flex justify-between items-center mb-5">
                <h3 className="font-bold text-slate-700 text-sm">الجمهور المستهدف (Primary)</h3>
                <AIButton onClick={handleSuggestPersona} loading={loadingField === 'persona-ai'} label="اقتراح الجمهور" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input label="العمر" value={data.primaryPersona.age} onChange={v => updatePersona('primary', 'age', v)} />
                <Input label="الجنس" value={data.primaryPersona.gender} onChange={v => updatePersona('primary', 'gender', v)} />
                <Input label="المناطق" value={data.primaryPersona.locations} onChange={v => updatePersona('primary', 'locations', v)} />
                <Input label="الاهتمامات" value={data.primaryPersona.interests} onChange={v => updatePersona('primary', 'interests', v)} />
              </div>
            </div>
            <Textarea label="رؤية المستهلك (Insight)" rows={2} value={data.consumerInsight} onChange={v => updateField('consumerInsight', v)} />
          </FormSection>

          <FormSection 
            title="5. المنتجات والخدمات" 
            englishTitle="Products"
            icon={<svg className="w-6 h-6 text-brand-teal" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" /></svg>}
          >
            <div className="space-y-6">
              <Textarea label="الخدمات والمنتجات الرئيسية" rows={3} value={data.serviceList} onChange={v => updateField('serviceList', v)} />
              <div>
                <Textarea label="المميزات والفوائد" rows={3} value={data.featuresBenefits} onChange={v => updateField('featuresBenefits', v)} />
                <AIButton onClick={() => handleImprove('featuresBenefits', 'المميزات والفوائد')} loading={loadingField === 'featuresBenefits'} />
              </div>
            </div>
          </FormSection>

          <FormSection 
            title="6. استراتيجية التسويق" 
            englishTitle="Strategy"
            borderColor="border-brand-teal"
            icon={<svg className="w-6 h-6 text-brand-teal" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" /></svg>}
          >
            <div className="space-y-6">
              <div>
                <Textarea label="الرسائل الرئيسية" rows={3} value={data.keyMessages} onChange={v => updateField('keyMessages', v)} />
                <AIButton onClick={handleSuggestMessages} loading={loadingField === 'messages-ai'} label="صياغة رسائل إبداعية" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <Input label="النبرة والأسلوب" value={data.toneStyle} onChange={v => updateField('toneStyle', v)} />
                <Input label="المخرجات المطلوبة" value={data.deliverables} onChange={v => updateField('deliverables', v)} />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-brand-green/5 border border-brand-green/10 rounded-2xl">
                  <Textarea label="نقاط القوة" rows={2} value={data.strengths} onChange={v => updateField('strengths', v)} />
                </div>
                <div className="p-4 bg-red-50/50 border border-red-100 rounded-2xl">
                  <Textarea label="نقاط الضعف" rows={2} value={data.weaknesses} onChange={v => updateField('weaknesses', v)} />
                </div>
              </div>
            </div>
          </FormSection>

          <FormSection 
            title="7. المنافسون" 
            englishTitle="Competitors"
            icon={<svg className="w-6 h-6 text-brand-teal" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>}
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {data.competitors.map((comp, idx) => (
                <div key={idx} className="bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                  <Input label={`منافس ${idx + 1}`} value={comp.name} onChange={v => updateCompetitor(idx, 'name', v)} />
                  <div className="mt-3">
                    <Input label="نقاط قوته" value={comp.strengths} onChange={v => updateCompetitor(idx, 'strengths', v)} />
                  </div>
                </div>
              ))}
            </div>
          </FormSection>

          <FormSection 
            title="8. الميزانية" 
            englishTitle="Budget"
            borderColor="border-brand-green"
            iconBgColor="bg-brand-green/10"
            icon={<svg className="w-6 h-6 text-brand-green" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <Input label="الميزانية المقترحة" value={data.budget} onChange={v => updateField('budget', v)} />
              <Input label="المواعيد النهائية" value={data.deadlines} onChange={v => updateField('deadlines', v)} />
            </div>
          </FormSection>

          <FormSection 
            title="9. ملاحظات إضافية" 
            englishTitle="Additional Notes"
            icon={<svg className="w-6 h-6 text-brand-teal" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" /></svg>}
          >
            <Textarea label="" rows={4} value={data.additionalNotes} onChange={v => updateField('additionalNotes', v)} placeholder="أي تفاصيل أخرى تود إضافتها..." />
          </FormSection>

        </form>

        {/* Footer Powered By */}
        <div className="text-center mt-12 mb-8 opacity-40">
           <p className="text-[10px] font-light tracking-[0.2em] uppercase text-slate-500">
             powered by content planet
           </p>
        </div>

        {/* Floating Actions */}
        <div className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-xl border-t border-slate-100 p-5 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)] flex flex-wrap justify-center items-center gap-4 no-print z-50">
          <button 
            onClick={() => window.print()} 
            className="bg-brand-teal hover:bg-brand-teal/90 text-white font-bold py-3.5 px-8 rounded-2xl shadow-lg shadow-brand-teal/20 transition-all transform active:scale-95 flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
            تصدير كـ PDF
          </button>
          
          <button 
            onClick={resetForm} 
            className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold py-3.5 px-8 rounded-2xl transition-all flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            إعادة تعيين
          </button>
        </div>
      </div>
    </div>
  );
};

// Helper Components
const Input = ({ label, value, onChange, placeholder, type = 'text' }: { label: string, value: string, onChange: (v: string) => void, placeholder?: string, type?: string }) => (
  <div className="group">
    <label className="text-[11px] font-extrabold text-slate-500 mb-2 block uppercase tracking-wider group-focus-within:text-brand-teal transition-colors">{label}</label>
    <input 
      type={type}
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full bg-slate-50/50 border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-brand-teal/20 focus:border-brand-teal focus:bg-white outline-none transition-all placeholder:text-slate-300"
    />
  </div>
);

const Textarea = ({ label, value, onChange, placeholder, rows }: { label: string, value: string, onChange: (v: string) => void, placeholder?: string, rows: number }) => (
  <div className="group">
    {label && <label className="text-[11px] font-extrabold text-slate-500 mb-2 block uppercase tracking-wider group-focus-within:text-brand-teal transition-colors">{label}</label>}
    <textarea 
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
      className="w-full bg-slate-50/50 border border-slate-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-brand-teal/20 focus:border-brand-teal focus:bg-white outline-none transition-all placeholder:text-slate-300 resize-none"
    />
  </div>
);

export default App;
