
import React from 'react';

interface FormSectionProps {
  title: string;
  englishTitle?: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  borderColor?: string;
  iconBgColor?: string;
}

const FormSection: React.FC<FormSectionProps> = ({ 
  title, 
  englishTitle, 
  icon, 
  children,
  borderColor = 'border-brand-teal',
  iconBgColor = 'bg-brand-teal/10'
}) => {
  return (
    <div className={`section-card bg-white rounded-2xl shadow-sm border-t-4 ${borderColor} p-6 md:p-8 mb-8 transition-all hover:shadow-md`}>
      <div className="flex items-center mb-6 border-b border-slate-50 pb-4">
        <div className={`${iconBgColor} p-3 rounded-xl ml-4 text-inherit`}>
          {icon}
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-800">{title}</h2>
          {englishTitle && <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{englishTitle}</p>}
        </div>
      </div>
      {children}
    </div>
  );
};

export default FormSection;
