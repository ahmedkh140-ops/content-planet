
import { GoogleGenAI, Type } from "@google/genai";
import { BriefData } from "../types";

// Always use the process.env.API_KEY directly as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const improveContent = async (text: string, fieldName: string): Promise<string> => {
  if (!text.trim()) return text;
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `بصفتك خبير استراتيجي في التسويق والإبداع، قم بتحسين النص التالي الخاص بـ "${fieldName}" في ملخص مشروع (Creative Brief). اجعله أكثر احترافية، وضوحاً، وجاذبية باللغة العربية.
      
      النص الحالي:
      "${text}"`,
    });
    
    return response.text?.trim() || text;
  } catch (error) {
    console.error("AI Improvement Error:", error);
    return text;
  }
};

export const suggestPersona = async (projectDescription: string): Promise<any> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `بناءً على وصف المشروع التالي: "${projectDescription}"، اقترح "شخصية العميل المثالي" (Primary Persona) في شكل JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            age: { type: Type.STRING },
            gender: { type: Type.STRING },
            locations: { type: Type.STRING },
            interests: { type: Type.STRING },
            problems: { type: Type.STRING }
          },
          required: ["age", "gender", "locations", "interests", "problems"]
        }
      }
    });
    
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("AI Persona Error:", error);
    return null;
  }
};

export const generateKeyMessages = async (data: BriefData): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `قم بصياغة 3 رسائل تسويقية قوية (Key Messages) بناءً على هذه البيانات:
      اسم الشركة: ${data.companyName}
      الوصف: ${data.projectDescription}
      نقاط الألم: ${data.painPoints}
      الأهداف: ${data.primaryGoal}`,
    });
    return response.text || '';
  } catch (error) {
    console.error("AI Messages Error:", error);
    return "";
  }
};
