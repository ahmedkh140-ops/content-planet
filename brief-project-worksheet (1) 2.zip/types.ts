
export interface BriefData {
  companyName: string;
  contactPerson: string;
  location: string;
  phone: string;
  socialChannels: string;
  projectDescription: string;
  painPoints: string;
  primaryGoal: string;
  secondaryGoal: string;
  problemSolved: string;
  cta: string;
  kpis: string;
  launchDate: string;
  primaryPersona: Persona;
  secondaryPersona: Persona;
  consumerInsight: string;
  buyingMotivations: string;
  serviceList: string;
  popularService: string;
  winnerService: string;
  leastKnownService: string;
  featuresBenefits: string;
  marketingChannels: string;
  keyMessages: string;
  toneStyle: string;
  deliverables: string;
  strengths: string;
  weaknesses: string;
  competitors: Competitor[];
  budget: string;
  deadlines: string;
  additionalNotes: string;
}

export interface Persona {
  age: string;
  gender: string;
  locations: string;
  interests: string;
  problems: string;
}

export interface Competitor {
  name: string;
  strengths: string;
}

export const initialBriefData: BriefData = {
  companyName: '',
  contactPerson: '',
  location: '',
  phone: '',
  socialChannels: '',
  projectDescription: '',
  painPoints: '',
  primaryGoal: '',
  secondaryGoal: '',
  problemSolved: '',
  cta: '',
  kpis: '',
  launchDate: '',
  primaryPersona: { age: '', gender: '', locations: '', interests: '', problems: '' },
  secondaryPersona: { age: '', gender: '', locations: '', interests: '', problems: '' },
  consumerInsight: '',
  buyingMotivations: '',
  serviceList: '',
  popularService: '',
  winnerService: '',
  leastKnownService: '',
  featuresBenefits: '',
  marketingChannels: '',
  keyMessages: '',
  toneStyle: '',
  deliverables: '',
  strengths: '',
  weaknesses: '',
  competitors: [
    { name: '', strengths: '' },
    { name: '', strengths: '' },
    { name: '', strengths: '' }
  ],
  budget: '',
  deadlines: '',
  additionalNotes: ''
};
