
import { 
  Document, 
  Packer, 
  Paragraph, 
  TextRun, 
  HeadingLevel, 
  AlignmentType, 
  Table, 
  TableRow, 
  TableCell, 
  BorderStyle, 
  WidthType, 
  ShadingType,
  VerticalAlign,
  Header,
  Footer
} from "docx";
import saveAs from "file-saver";
import { BriefData } from "../types";

// الألوان المستخدمة في التصميم (HEX)
const COLORS = {
  primary: "3B82F6",    // Blue 500
  secondary: "F8FAFC",  // Slate 50
  textDark: "1E293B",   // Slate 800
  textLight: "64748B",  // Slate 500
  border: "E2E8F0"      // Slate 200
};

/**
 * دالة لإنشاء عنوان قسم مشابه لتصميم التطبيق
 */
const createSectionHeader = (number: string, title: string, englishTitle: string) => {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 24, color: COLORS.primary },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: COLORS.border },
      left: { style: BorderStyle.NONE },
      right: { style: BorderStyle.NONE },
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            children: [
              new Paragraph({
                // Add bidirectional support for RTL
                bidirectional: true,
                children: [
                  new TextRun({ text: `${number}. ${title}`, bold: true, size: 28, color: COLORS.textDark }),
                ],
                alignment: AlignmentType.RIGHT,
                spacing: { before: 100 },
              }),
              new Paragraph({
                // Add bidirectional support for RTL
                bidirectional: true,
                children: [
                  new TextRun({ text: englishTitle, size: 18, color: COLORS.textLight, smallCaps: true }),
                ],
                alignment: AlignmentType.RIGHT,
                spacing: { after: 100 },
              }),
            ],
            shading: { fill: COLORS.secondary, type: ShadingType.CLEAR },
            verticalAlign: VerticalAlign.CENTER,
            margins: { top: 100, bottom: 100, right: 200, left: 200 },
          }),
        ],
      }),
    ],
  });
};

/**
 * دالة لإنشاء حقل (عنوان وقيمة)
 */
const createFieldRow = (label: string, value: string) => {
  return new Paragraph({
    // Add bidirectional support for RTL
    bidirectional: true,
    children: [
      new TextRun({ text: `${label}: `, bold: true, color: COLORS.textDark, size: 22 }),
      new TextRun({ text: value || "---", color: COLORS.textDark, size: 22 }),
    ],
    alignment: AlignmentType.RIGHT,
    spacing: { before: 120, after: 120 },
  });
};

export const downloadAsWord = async (data: BriefData) => {
  const children: any[] = [];

  // 1. الشعار والعنوان الرئيسي
  children.push(
    new Paragraph({
      // Add bidirectional support for RTL
      bidirectional: true,
      children: [
        new TextRun({ text: "Brief Project Worksheet", bold: true, size: 48, color: COLORS.textDark }),
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: 800 },
    })
  );

  // 1. General Information
  children.push(createSectionHeader("1", "معلومات عامة", "General Information"));
  children.push(createFieldRow("اسم الشركة / العلامة التجارية", data.companyName));
  children.push(createFieldRow("الشخص المسؤول للتواصل", data.contactPerson));
  children.push(createFieldRow("موقع الشركة", data.location));
  children.push(createFieldRow("رقم الهاتف", data.phone));
  children.push(createFieldRow("قنوات التواصل الاجتماعي", data.socialChannels));
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: "" })], spacing: { after: 400 } }));

  // 2. Project Description
  children.push(createSectionHeader("2", "وصف المشروع", "Project Description"));
  children.push(createFieldRow("وصف المشروع", data.projectDescription));
  children.push(createFieldRow("نقاط الألم لدى العميل", data.painPoints));
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: "" })], spacing: { after: 400 } }));

  // 3. Objectives
  children.push(createSectionHeader("3", "الأهداف والغايات", "Objectives and Goals"));
  children.push(createFieldRow("الهدف الرئيسي", data.primaryGoal));
  children.push(createFieldRow("الهدف الثانوي", data.secondaryGoal));
  children.push(createFieldRow("المشكلة التي يتم حلها", data.problemSolved));
  children.push(createFieldRow("الإجراء المطلوب (CTA)", data.cta));
  children.push(createFieldRow("مؤشرات النجاح (KPIs)", data.kpis));
  children.push(createFieldRow("تاريخ الإطلاق", data.launchDate));
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: "" })], spacing: { after: 400 } }));

  // 4. Audience
  children.push(createSectionHeader("4", "معلومات الجمهور", "Audience Information"));
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: "الجمهور الأساسي (Primary Persona):", bold: true, color: COLORS.primary })], alignment: AlignmentType.RIGHT, spacing: { before: 200 } }));
  children.push(createFieldRow("الفئة العمرية", data.primaryPersona.age));
  children.push(createFieldRow("الجنس", data.primaryPersona.gender));
  children.push(createFieldRow("المناطق", data.primaryPersona.locations));
  children.push(createFieldRow("الاهتمامات", data.primaryPersona.interests));
  children.push(createFieldRow("التحديات", data.primaryPersona.problems));
  children.push(createFieldRow("رؤية المستهلك", data.consumerInsight));
  children.push(createFieldRow("دوافع الشراء", data.buyingMotivations));
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: "" })], spacing: { after: 400 } }));

  // 5. Products/Services
  children.push(createSectionHeader("5", "المنتجات والخدمات", "Products and Services"));
  children.push(createFieldRow("قائمة الخدمات", data.serviceList));
  children.push(createFieldRow("الخدمة الأكثر شهرة", data.popularService));
  children.push(createFieldRow("الخدمة الرابحة", data.winnerService));
  children.push(createFieldRow("الخدمة الأقل شهرة", data.leastKnownService));
  children.push(createFieldRow("المميزات والفوائد", data.featuresBenefits));
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: "" })], spacing: { after: 400 } }));

  // 6. Strategy
  children.push(createSectionHeader("6", "استراتيجية التسويق", "Strategy and Messages"));
  children.push(createFieldRow("القنوات المستهدفة", data.marketingChannels));
  children.push(createFieldRow("الرسائل الرئيسية", data.keyMessages));
  children.push(createFieldRow("النبرة والأسلوب", data.toneStyle));
  children.push(createFieldRow("المخرجات المطلوبة", data.deliverables));
  children.push(createFieldRow("نقاط القوة", data.strengths));
  children.push(createFieldRow("نقاط الضعف", data.weaknesses));
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: "" })], spacing: { after: 400 } }));

  // 7. Competitors
  children.push(createSectionHeader("7", "المنافسون", "Competitors"));
  data.competitors.forEach((comp, idx) => {
    if (comp.name) {
      children.push(createFieldRow(`المنافس ${idx + 1}`, `${comp.name} (نقاط القوة: ${comp.strengths})`));
    }
  });
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: "" })], spacing: { after: 400 } }));

  // 8. Budget & Schedule
  children.push(createSectionHeader("8", "الميزانية والجدول الزمني", "Budget and Schedule"));
  children.push(createFieldRow("الميزانية", data.budget));
  children.push(createFieldRow("المواعيد النهائية", data.deadlines));
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: "" })], spacing: { after: 400 } }));

  // 9. Additional Notes
  children.push(createSectionHeader("9", "ملاحظات إضافية", "Additional Notes"));
  children.push(new Paragraph({ bidirectional: true, children: [new TextRun({ text: data.additionalNotes || "لا توجد ملاحظات إضافية" })], alignment: AlignmentType.RIGHT, spacing: { before: 200 } }));

  const doc = new Document({
    sections: [{
      properties: {
        // RTL is handled per paragraph.
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: "powered by content planet",
                  size: 16,
                  color: "94A3B8", // Slate 400
                  smallCaps: true,
                }),
              ],
              alignment: AlignmentType.CENTER,
            }),
          ],
        }),
      },
      children: children,
    }],
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `${data.companyName || 'Brief'}_Project_Worksheet.docx`);
};
